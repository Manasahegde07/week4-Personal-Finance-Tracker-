from finance_tracker.expense_manager import ExpenseManager
from finance_tracker.reports import monthly_report, category_report

class FinanceTracker:
    def __init__(self):
        self.manager = ExpenseManager()

    def run(self):
        while True:
            print("\n" + "=" * 40)
            print("   PERSONAL FINANCE TRACKER")
            print("=" * 40)
            print("1. Add Expense")
            print("2. View All Expenses")
            print("3. Search by Category")
            print("4. Monthly Report")
            print("5. Category Report")
            print("0. Exit")

            choice = input("Enter choice: ").strip()

            if choice == "1":
                self.add_expense()
            elif choice == "2":
                self.view_expenses()
            elif choice == "3":
                self.search_category()
            elif choice == "4":
                monthly_report(self.manager.get_all_expenses())
            elif choice == "5":
                category_report(self.manager.get_all_expenses())
            elif choice == "0":
                print("Thank you for using Finance Tracker!")
                break
            else:
                print("Invalid choice!")

    def add_expense(self):
        try:
            amount = float(input("Enter amount: "))
            category = input("Enter category: ").strip()
            description = input("Enter description: ").strip()
            self.manager.add_expense(amount, category, description)
            print("✅ Expense added successfully!")
        except ValueError:
            print("❌ Invalid amount!")

    def view_expenses(self):
        expenses = self.manager.get_all_expenses()
        if not expenses:
            print("No expenses found.")
            return

        for i, e in enumerate(expenses, 1):
            print(f"{i}. ₹{e['amount']} | {e['category']} | {e['description']} | {e['date']}")

    def search_category(self):
        category = input("Enter category to search: ")
        results = self.manager.search_by_category(category)
        if not results:
            print("No matching expenses.")
            return

        for e in results:
            print(f"₹{e['amount']} | {e['description']} | {e['date']}")
