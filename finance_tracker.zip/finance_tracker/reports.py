def monthly_report(expenses):
    total = sum(e["amount"] for e in expenses)
    print("\n--- MONTHLY REPORT ---")
    print(f"Total Expenses: ₹{total}")

def category_report(expenses):
    summary = {}

    for e in expenses:
        summary[e["category"]] = summary.get(e["category"], 0) + e["amount"]

    print("\n--- CATEGORY REPORT ---")
    for cat, amt in summary.items():
        print(f"{cat}: ₹{amt}")
